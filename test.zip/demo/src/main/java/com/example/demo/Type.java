package com.example.demo;

public enum Type {
	PETROL,
	DIESEL,
	ELECTRIC,
	HYBRID
}
